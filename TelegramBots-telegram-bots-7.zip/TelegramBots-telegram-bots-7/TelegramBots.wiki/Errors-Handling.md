* [Terminated by other long poll or webhook](#terminted_by_other)
* ["No implementation for org.telegram.telegrambots.meta.generics.BotSession was bound"](#no_implementation_was_bound)

## <a id="terminted_by_other"></a>Terminated by other long poll or webhook ##

It means that you have already a running instance of your bot. To solve it, close all running ones and then you can start a new instance.
